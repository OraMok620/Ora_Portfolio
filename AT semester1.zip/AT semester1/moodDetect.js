//Global Variables
let faceApi;          
let detections = [];   
let video;             

//Colour
const emotionColours = {
  neutral: "#ffffff", 
  happy: "#ffdc13ff", 
  angry: "#a00c0cff", 
  sad: "#868686ff", 
  disgusted: "#2a6e19ff", 
  surprised: "#ff89b8ff", 
  fearful: "#6e337aff"
};

const emotionToFolderMap = { neutral:1, happy:2, sad:3, angry:4, disgusted:5, fearful:6, surprised:7 };

//Settings
let currentEmotion = "neutral";  
let targetEmotion = "neutral";   
let emotionCounts = { neutral:0, happy:0, angry:0, sad:0, disgusted:0, surprised:0, fearful:0 };
let transitionProgress = 0;      
let lastUpdateTime = 0;          
let isDetectionActive = true;    

function setup() {
  video = createCapture(VIDEO);
  video.size(320, 240);  
  video.hide();    
  createCanvas(320, 240).hide();
  
  const faceOptions = { withLandmarks:true, withExpressions:true, withDescriptors:true, minConfidence:0.5 };
  faceapi = ml5.faceApi(video, faceOptions, faceReady);
  lastUpdateTime = millis();
}

function faceReady() { faceapi.detect(gotFaces); }

function gotFaces(error, result) {
  if (error) return;
  detections = result;  
  if (isDetectionActive) faceapi.detect(gotFaces);
}

//Emotion detection and folder changing
function updateEmotion() {
  if (!isDetectionActive) return;
  
  if (detections.length > 0) {
    let {neutral, happy, angry, sad, disgusted, surprised, fearful} = detections[0].expressions;
    
    let maxVal = neutral;
    let frameEmotion = "neutral";
    
    const emotions = [
      {name: "happy", value: happy}, {name: "angry", value: angry}, {name: "sad", value: sad},
      {name: "disgusted", value: disgusted}, {name: "surprised", value: surprised},
      {name: "fearful", value: fearful}, {name: "neutral", value: neutral}
    ];
    
    emotions.forEach(emotion => {
      if (emotion.value > maxVal) { maxVal = emotion.value; frameEmotion = emotion.name; }
    });

    emotionCounts[frameEmotion]++;
    
    const currentTime = millis();
    if (currentTime - lastUpdateTime > UPDATE_INTERVAL) {
      let maxCount = 0;
      let newTargetEmotion = targetEmotion;
      
      for (let emotion in emotionCounts) {
        if (emotionCounts[emotion] > maxCount) {
          maxCount = emotionCounts[emotion];
          newTargetEmotion = emotion;
        }
      }

      if (newTargetEmotion !== targetEmotion && maxCount > 3) {
        targetEmotion = newTargetEmotion;
        transitionProgress = 0;
        triggerFolderChangeForEmotion(targetEmotion);
      }
      
      for (let emotion in emotionCounts) emotionCounts[emotion] = 0;
      lastUpdateTime = currentTime;
    }
  }
}

//Select folder based on emotion
function triggerFolderChangeForEmotion(emotion) {
  const folderId = emotionToFolderMap[emotion];
  
  if (folderId && typeof window.selectFolder === 'function') {
    const currentFolder = window.currentFolderId || 1;
    
    if (folderId !== currentFolder) {
      const isMusicPlaying = window.isPlaying || false;
      
      if (!isMusicPlaying) {
        window.selectFolder(folderId);
      }
    }
  }
}

//UI transition
function colourTransition() {
  if (currentEmotion !== targetEmotion) {
    transitionProgress += TRANSITION_SPEED;
    if (transitionProgress >= 1) {
      transitionProgress = 1;
      currentEmotion = targetEmotion;
    }
    const currentColour = emotionColours[currentEmotion];
    const targetColour = emotionColours[targetEmotion];

    if (transitionProgress < 1) {
      const blendedColour = interpolateColour(currentColour, targetColour, transitionProgress);
      updateUITheme(blendedColour, targetEmotion);
    } else {
      updateUITheme(targetColour, targetEmotion);
    }
  }
}

function updateUITheme(colour, emotion) {
  document.documentElement.style.setProperty('--theme-colour', colour);
  document.documentElement.style.setProperty('--theme-emotion', emotion);
}

//Control detection
function pauseDetection() { isDetectionActive = false; }
function resumeDetection() { isDetectionActive = true; }

//p5.js draw loop
function draw() { updateEmotion(); colourTransition(); }

//Export functions for musicPlayer.js
window.moodDetect = {
  pauseDetection: pauseDetection,
  resumeDetection: resumeDetection,
  getCurrentEmotion: () => currentEmotion,
  getTargetEmotion: () => targetEmotion
};