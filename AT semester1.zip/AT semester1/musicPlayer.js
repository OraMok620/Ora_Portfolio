//DOM Elements
const folderToggleBtn = document.getElementById('folderToggleBtn');
const folderPanel = document.getElementById('folderPanel');
const overlay = document.getElementById('overlay');
const folderListElement = document.getElementById('folderList');
const dragDropArea = document.getElementById('dragDropArea');
const fileInput = document.getElementById('fileInput');
const playlistElement = document.getElementById('playlist');
const trackTitleElement = document.getElementById('trackTitle');
const trackArtistElement = document.getElementById('trackArtist');
const playPauseBtn = document.getElementById('playPauseBtn');
const playIcon = document.getElementById('playIcon');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const progressElement = document.getElementById('progress');
const progressBar = document.getElementById('progressBar');
const currentTimeElement = document.getElementById('currentTime');
const durationElement = document.getElementById('duration');
const volumeSlider = document.getElementById('volumeSlider');
const audioPlayer = document.getElementById('audioPlayer');

//Folder Data
const folders = [
    { id: 1, name: "Neutral", icon: "🙂"},
    { id: 2, name: "Happy", icon: "😄"},
    { id: 3, name: "Sad", icon: "😭" },
    { id: 4, name: "Angry", icon: "😡"},
    { id: 5, name: "Disgusted", icon: "🤢"},
    { id: 6, name: "Fearful", icon: "😱" },
    { id: 7, name: "Surprised", icon: "😆" }
];

//Global variables
let tracks = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [] };
let currentFolderId = null;
let currentTrackIndex = null;
let isPlaying = false;
let currentVolume = 0.5;
let allTracks = [];
let objectURLs = {};

//Initialize application
function initializeApp() {
    renderFolders();
    eventListener();
    updatePlaylist();
    audioPlayer.volume = currentVolume;
    selectFolder(1);
    
    window.selectFolder = selectFolder;
    window.playTrack = playTrack;
    window.updatePlaylist = updatePlaylist;
    window.currentFolderId = currentFolderId;
    window.allTracks = allTracks;
    window.isPlaying = isPlaying;
}

//Folder management
function renderFolders() {
    folderListElement.innerHTML = '';
    folders.forEach(folder => {
        const folderItem = document.createElement('div');
        folderItem.className = 'folder-item';
        folderItem.innerHTML = `<span class="folder-icon">${folder.icon}</span>${folder.name}<span class="track-count">${tracks[folder.id].length}</span>`;
        folderItem.dataset.folderId = folder.id;
        folderItem.addEventListener('click', () => {selectFolder(folder.id);});
        folderListElement.appendChild(folderItem);
    });
}

function selectFolder(folderId) {
    currentFolderId = folderId;
    
    document.querySelectorAll('.folder-item').forEach(item => {
        item.classList.remove('active');
        if (parseInt(item.dataset.folderId) === folderId) {
            item.classList.add('active');
        }
    });
    updatePlaylist();
    if (currentTrackIndex !== null) {
        const currentTrack = allTracks[currentTrackIndex];
        if (currentTrack.folderId !== currentFolderId) {
            resetTrackSelection();
        }
    }
}

function resetTrackSelection() {
    currentTrackIndex = null;
    trackTitleElement.textContent = 'No Track Selected';
    trackArtistElement.textContent = 'Select a track to play';
    audioPlayer.src = '';
    updatePlayButton();
}

//Add track to folder
function addTrackToFolder(folderId, file, title, artist, duration) {
    const objectURL = URL.createObjectURL(file);
    const trackId = Date.now() + Math.random();
    const newTrack = { id: trackId, title: title, artist: artist, duration: duration, folderId: folderId, file: file, objectURL: objectURL };
    
    tracks[folderId].push(newTrack);
    allTracks.push(newTrack);
    objectURLs[trackId] = objectURL;
    
    if (folderId === currentFolderId) updatePlaylist();
    return newTrack;
}

//Update playlist
function updatePlaylist() {
    playlistElement.innerHTML = '';
    const currentFolderTracks = allTracks.filter(track => track.folderId === currentFolderId);
    
    if (currentFolderTracks.length === 0) {
        playlistElement.innerHTML = `<div class="text-center text-muted py-4">No tracks in folder</div>`;
        return;
    }
    
    currentFolderTracks.forEach((track, index) => {
        const allTracksIndex = allTracks.findIndex(t => t.id === track.id);
        const folder = folders.find(f => f.id === track.folderId);
        const folderIcon = folder ? folder.icon : '📁';
        
        const playlistItem = document.createElement('div');
        playlistItem.className = 'playlist-item';
        if (currentTrackIndex === allTracksIndex) playlistItem.classList.add('playing');
        
        playlistItem.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <span class="me-2">${folderIcon}</span>
                    <div>
                        <div class="fw-medium">${track.title}</div>
                        <small class="text-muted">${track.artist}</small>
                    </div>
                </div>
                <span class="badge bg-light text-dark">${track.duration}</span>
            </div>
        `;
        
        playlistItem.dataset.trackIndex = allTracksIndex;
        playlistItem.addEventListener('click', () => { selectTrackFromPlaylist(allTracksIndex); });
        playlistElement.appendChild(playlistItem);
    });
}

function selectTrackFromPlaylist(trackIndex) {
    if (trackIndex < 0 || trackIndex >= allTracks.length) return;
    const track = allTracks[trackIndex];
    currentTrackIndex = trackIndex;
    updatePlaylist();
    trackTitleElement.textContent = track.title;
    trackArtistElement.textContent = track.artist;
    if (track.objectURL) audioPlayer.src = track.objectURL;
    updatePlayButton();
}

//Playback control
function playTrack() {
    if (currentTrackIndex === null) return;
    
    if (!audioPlayer.src && allTracks[currentTrackIndex]?.objectURL) {
        audioPlayer.src = allTracks[currentTrackIndex].objectURL;
    }
    
    audioPlayer.play().then(() => {
        isPlaying = true;
        updatePlayButton();
        if (window.moodDetect) window.moodDetect.pauseDetection();
    });
}

function pauseTrack() {
    audioPlayer.pause();
    isPlaying = false;
    updatePlayButton();
    if (window.moodDetect) window.moodDetect.resumeDetection();
}

function updatePlayButton() {
    if (isPlaying) {
        playIcon.className = "bi bi-pause";
        playPauseBtn.title = "Pause";
    } else {
        playIcon.className = "bi bi-play";
        playPauseBtn.title = "Play";
    }
}

//Event listener
function eventListener() {
    folderToggleBtn.addEventListener('click', toggleFolderPanel);
    closeFolderPanelBtn.addEventListener('click', toggleFolderPanel);
    overlay.addEventListener('click', toggleFolderPanel);
    
    playPauseBtn.addEventListener('click', () => {
        if (currentTrackIndex === null) {
            const currentFolderTracks = allTracks.filter(track => track.folderId === currentFolderId);
            if (currentFolderTracks.length > 0) {
                const firstTrack = currentFolderTracks[0];
                currentTrackIndex = allTracks.findIndex(t => t.id === firstTrack.id);
                updatePlaylist();
                trackTitleElement.textContent = firstTrack.title;
                trackArtistElement.textContent = firstTrack.artist;
                if (firstTrack.objectURL) audioPlayer.src = firstTrack.objectURL;
                updatePlayButton();
            }
            return;
        }
        
        if (isPlaying) pauseTrack();
        else playTrack();
    });
    
    prevBtn.addEventListener('click', playPreviousTrack);
    nextBtn.addEventListener('click', playNextTrack);
    
    audioPlayer.addEventListener('timeupdate', updateProgress);
    audioPlayer.addEventListener('ended', playNextTrack);
    
    progressBar.addEventListener('click', setProgress);
    
    volumeSlider.addEventListener('input', (e) => {
        currentVolume = e.target.value;
        audioPlayer.volume = currentVolume;
    });
    
    //Upload file
    dragDropArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        dragDropArea.classList.add('dragover');
    });
    
    dragDropArea.addEventListener('dragleave', () => {
        dragDropArea.classList.remove('dragover');
    });
    
    dragDropArea.addEventListener('drop', handleFileDrop);
    
    dragDropArea.addEventListener('click', () => {
        if (currentFolderId === null) selectFolder(1);
        fileInput.click();
    });
    
    fileInput.addEventListener('change', async (e) => {
        const files = e.target.files;
        for (let file of files) {
            if (file.type.startsWith('audio/')) {
                const fileName = file.name.replace(/\.[^/.]+$/, "");
                const duration = await getAudioDuration(file);
                const durationFormatted = formatTime(duration);
                addTrackToFolder(currentFolderId, file, fileName, "Unknown Artist", durationFormatted);
            }
        }
        fileInput.value = '';
        updatePlaylist();
    });
}

//Start the app
document.addEventListener('DOMContentLoaded', initializeApp);